# 0xC0000005 · Hugo + GitHub Pages Starter

A complete English-language Hugo blog package: reusable theme, real sample site and posts, a Markdown feature showcase, a one-time GitHub Actions ZIP importer, and the regular GitHub Pages build/deploy workflow. The blog name and creator are both **0xC0000005**.

## Package contents

- `bootstrap-workflow.yml`: copy this into the target repository as `.github/workflows/unpack-starter.yml` for the one-time import.
- `Gilded-Page-Hugo-GitHub-Lazy-Pack.zip`: upload this archive to the target repository root.
- `site/`: complete Hugo source, with the reusable theme in `themes/gilded-page/`, sample posts, and the normal Pages workflow.
- `preview/`: built static preview.

## First-time import with GitHub Actions

The importer runs on a GitHub-hosted Linux runner. It extracts the ZIP, copies the contents of its `site/` directory into the repository root, removes the uploaded ZIP, and commits the result. It preserves the repository README and stops before copying if it detects conflicting files.

### 1. Create the repository

Create a repository named `kxenon0rix.github.io` (or another name you prefer) and initialize it with a README so it has a default branch.

### 2. Create a fine-grained token

In **Settings → Developer settings → Fine-grained personal access tokens**, create a token with: **Only select repositories** (select this one repository), **Contents: Read and write**, and **Workflows: Read and write**. Metadata read access is automatic. Set an expiration. Do not grant Actions, Pages, or Administration permissions.

Add the token to the target repository under **Settings → Secrets and variables → Actions** as a Repository secret named `BOOTSTRAP_TOKEN`.

### 3. Upload the ZIP and importer workflow

1. Upload `Gilded-Page-Hugo-GitHub-Lazy-Pack.zip` to the repository root. Keep the filename unchanged.
2. Create `.github/workflows/unpack-starter.yml` in the repository and paste in the full contents of this package's `bootstrap-workflow.yml`. Commit the file.
3. Open **Actions → One-time unzip Hugo starter → Run workflow**. Keep the default archive path and run it.

After import, the archive is removed and the regular `Build and deploy Hugo site` workflow should run. The importer uses the fine-grained token stored in `BOOTSTRAP_TOKEN`; the site deployment uses the workflow's short-lived `GITHUB_TOKEN`. Once the site is deployed, you can revoke the bootstrap token and delete the importer workflow and secret.

### 4. Enable Pages

Open **Settings → Pages → Build and deployment → Source** and choose **GitHub Actions**. The user-site URL for the repository `kxenon0rix.github.io` is `https://kxenon0rix.github.io/`.

## Local development

Install Hugo 0.146 or later, then run from `site/`:

```sh
hugo server
```

Add posts under `site/content/articles/`. Copy an existing Markdown file and edit its title, date, description, category, and image. The site title and author are configured in `site/hugo.toml`; the About page is in `site/content/about/index.md`; the carousel is in `site/themes/gilded-page/layouts/home.html`.

The footer slogan is “Beyond the obvious.” Change it with `params.slogan` in `site/hugo.toml`. The site configuration file is named `hugo.toml`, not `site.toml`.

## Deployment model

This is a traditional static blog: Hugo builds Markdown and theme files into HTML, CSS, and JavaScript; GitHub Actions publishes the generated site to GitHub Pages. Posts are stored in the repository, not in GitHub Issues.
