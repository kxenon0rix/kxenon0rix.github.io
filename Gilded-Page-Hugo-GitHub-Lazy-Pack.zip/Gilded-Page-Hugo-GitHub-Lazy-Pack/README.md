# 0xC0000005 · Hugo + GitHub Pages 懒人包

这是一个完整的 Hugo 静态博客项目：可复用主题、真实示例站点和文章、Markdown 演示文章、GitHub Pages 自动构建部署流程，以及一份手动触发的一次性 GitHub Actions 工作流模板。博客标题和作者名均为 **0xC0000005**。

## 包内内容

```text
Gilded-Page-Hugo-GitHub-Lazy-Pack/
├── README.md                 本说明
├── bootstrap-workflow.yml    一次性解压工作流模板
├── site/                     Hugo 站点源文件
│   ├── hugo.toml
│   ├── content/              关于页和示例文章
│   ├── themes/gilded-page/   可复用主题
│   └── .github/workflows/    常规 Hugo 构建与部署工作流
└── preview/                  已构建站点预览
```

站点包含旅行、日常、阅读和技术文章，以及完整 Markdown 示例：目录、提示块、代码语言标签与复制、Mermaid 思维导图、数学公式。

## 首次部署：一次性 GitHub Actions 解压 ZIP

这一步由 GitHub Actions 的 Linux runner 解压并导入站点文件，不需要在本机运行安装脚本。工作流会保留仓库 README；如果目标路径已有文件，会停止并列出冲突，不覆盖已有文件。导入成功后会删除仓库中的 ZIP，并提交、推送站点源码。

### 1. 创建目标仓库

在 GitHub 创建一个新仓库，并勾选添加 `README.md`，使仓库有默认分支。示例名：`alice/my-blog`。

### 2. 创建细颗粒度令牌

在 GitHub 的 **Settings → Developer settings → Fine-grained personal access tokens → Generate new token** 配置：

- **Resource owner**：目标仓库所属账号或组织。
- **Repository access**：选 **Only select repositories**，只勾选这个目标仓库。
- **Repository permissions**：
  - **Contents：Read and write**
  - **Workflows：Read and write**（导入时会提交 `.github/workflows/hugo-pages.yml`）
  - **Metadata：Read-only**（自动提供）
- 不给 Actions、Pages、Administration 或其他仓库权限；设置较短的有效期。

GitHub 要求令牌推送工作流文件时具备 `Workflows` 写入权限。令牌是密码，不要放进 ZIP 或发给他人。

### 3. 上传 ZIP 并添加一次性工作流

1. 将本 ZIP 原样上传到目标仓库根目录，文件名保持 `Gilded-Page-Hugo-GitHub-Lazy-Pack.zip`。
2. 在目标仓库的 **Settings → Secrets and variables → Actions** 新建 Repository secret：
   - Name：`BOOTSTRAP_TOKEN`
   - Secret：刚创建的细颗粒度令牌
3. 在仓库中新建 `.github/workflows/unpack-starter.yml`，把本包里的 `bootstrap-workflow.yml` 内容粘贴进去并提交。
4. 打开仓库 **Actions → One-time unzip Hugo starter → Run workflow**，保持 ZIP 路径为默认值，运行。

完成后，Actions 会把 ZIP 中 `site/` 的内容导入仓库根目录，删除上传的 ZIP，然后使用令牌提交和推送。因为这次推送由 PAT 发起，普通的 Hugo Pages `push` 工作流会正常触发。

### 4. 开启 GitHub Pages 发布

进入仓库 **Settings → Pages → Build and deployment → Source**，选择 **GitHub Actions**。导入提交会自动触发 `Build and deploy Hugo site` 工作流；后续每次推送文章也会自动构建并部署。

常规部署工作流只申请 `contents: read`、`pages: write`、`id-token: write`，用 GitHub Actions 自动提供的 `GITHUB_TOKEN` 发布页面，不需要将个人令牌用于日常部署。首次导入完成并确认发布后，可撤销 `BOOTSTRAP_TOKEN`，也可删除 `unpack-starter.yml` 和对应 secret。

### 冲突或重跑

一次性工作流不会覆盖仓库已有文件。如果它报告冲突，请先备份并移除冲突文件，再重新运行。成功后 ZIP 已删除；若需要重跑，重新上传 ZIP 并保留或重新添加工作流即可。

## 本地预览和写文章

在 `site/` 目录安装 Hugo 0.146 或更高版本后运行：

```sh
hugo server
```

文章放在 `site/content/articles/`，复制现有 Markdown 文件并修改 YAML front matter 中的标题、日期、摘要、分类和图片。站点名和作者名在 `site/hugo.toml`；关于页在 `site/content/about/index.md`；轮播文案在主题的 `layouts/home.html`。

查看包内预览：在懒人包根目录运行 `python -m http.server 8000 --directory preview`，然后打开 `http://localhost:8000`。

## 部署原理

这是传统静态站点部署：Hugo 将 Markdown 和主题构建成 HTML/CSS/JS，GitHub Actions 把生成结果发布到 GitHub Pages。文章源文件保存在仓库的 `content/`，不是 GitHub Issues。
